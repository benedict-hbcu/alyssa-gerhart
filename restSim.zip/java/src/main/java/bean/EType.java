package bean;

public enum EType {

    APPETIZER,
    MAIN,
    DESSERT

}
